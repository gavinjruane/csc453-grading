                              Project 1 README - Gavin Ruane
                                   Round-Robin Scheduler

-----------------------------------------------------------------------------------------

| Instructions |
1. Please use the included Makefile to compile the "schedule" program.
2. Use the format specified in the project manual to run "schedule". (Or, try running
   "schedule" without any arguments!)

| Notes |
- The C source file for the "two" program is included in this archive; however, it has
  not been compiled, and it will need to be compiled separately from the Makefile.

-----------------------------------------------------------------------------------------

