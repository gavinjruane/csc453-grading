#define _GNU_SOURCE

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <string.h>
#include <signal.h>

#include "schedule.h"

/* Global Variables
   (used to pass information to and from signal handlers) */
proc_t *current_proc = NULL;
proc_t *next_proc = NULL;
proc_t *proc_table_start = NULL;
int num_programs;
struct itimerval timer;

/* Signal Status Variables */
volatile int received_sigalrm = 0;
volatile int received_sigchld = 0;

/* Signal Mask Templates */
sigset_t sigchld_mask, sigchld_old_mask;
sigset_t sigalrm_mask, sigalrm_old_mask;



/* alarm_handler:
   Runs when parent receives a SIGALRM. Sets a volatile status (int) variable
   alerting round_robin() to the reception of a SIGALRM. */
void alarm_handler(int signal) {
	received_sigalrm = 1;
	return;
}

/* sigchld_handler:
   Runs when parent receives a SIGCHLD. Sets a volatile status (int) variable
   alerting round_robin() to the reception of a SIGCHLD. */
void sigchld_handler(int signal) {
	received_sigchld = 1;
	return;
}

/* error_handler:
   Prints various error messages to stderr. */
void error_handler(enum SCHED_ERR error) {
	switch ( error ) {
		case ERR_TIMER:
			fprintf(stderr, "schedule: could not set interval timer\n");
			break;
		case ERR_MAX_PROCS:
			fprintf(stderr, "schedule: number of processes exceeds limit (%d)", MAX_PROCESSES);
			break;
		case ERR_NESTED:
			fprintf(stderr, "schedule: schedule cannot run itself\n");	
			break;
		case ERR_FORK:
			fprintf(stderr, "schedule: error forking a process\n");
			break;
		case ERR_EXEC:
			fprintf(stderr, "schedule: error using exec\n");
			break;
		case ERR_USAGE:
			fprintf(stderr, "schedule: usage: schedule <program> <args> : ...\n");
			break;
		case ERR_QUANTUM:
			fprintf(stderr, "schedule: quantum must be a positive nonzero integer\n");
			break;
		case ERR_MAX_ARGS:
			fprintf(stderr, "schedule: number of arguments exceeds limit (%d)\n", MAX_ARGUMENTS);
			break;
		case ERR_RAISE:
			fprintf(stderr, "schedule: could not raise a SIGSTOP in child\n");
			break;
		case ERR_KILL:
			fprintf(stderr, "schedule: could not start first process\n");
			break;
		default:
			fprintf(stderr, "schedule: unknown error\n");
			break;
	}

	return;
}

/* set_timer:
   Sets an interval timer according to provided quantum. */
int set_timer(int quantum) {
	struct itimerval timer;

	timer.it_value.tv_sec = quantum / 1000;
	timer.it_value.tv_usec = (quantum % 1000) * 1000;
	timer.it_interval = timer.it_value;

	if ( setitimer(ITIMER_REAL, &timer, NULL) == -1 ) {
		perror("schedule: setitimer:");
		error_handler(ERR_TIMER);
		return -1;
	}

	return 0;
}

/* find_colon:
   Finds a colon (":") in argv and returns a pointer to it. Used in processing
   the arguments provided to schedule. When a colon is found, find_colon() will
   return a pointer to the colon + 1--in other words, the next non-colon 
   argument (the name of the next program). */
char **find_colon(char **argv) {
	int i = 0;
	while ( (argv[i] != NULL) && (strcmp(argv[i], ":") != 0) ) {
		i++;
	}
	argv[i] = NULL;
	
	if ( argv[i + 1] == NULL ) {
		return NULL;
	} else if ( i > MAX_ARGUMENTS ) {
		error_handler(ERR_MAX_ARGS);
		return NULL;
	} else {
		return &argv[i + 1];
	}
}

/* get_num_programs:
   Returns the number of programs provided as arguments to schedule; value used 
   in various places throughout program for looping, allocating memory, and
   moving through the proc_table. */
int get_num_programs(int argc, char **argv) {
	int i = 0;
	int num_programs = 0;

	while ( i != (argc - 2) ) {
		if ( strcmp(argv[i], ":") == 0 ) {
			num_programs++;
		}
		i++;
	}
	num_programs++;  /* Add one to num_programs because #colons always -1
			    actual program count */

	if ( num_programs >= MAX_PROCESSES ) {
		return -1;
	} else {
		return num_programs;
	}
}

/* get_num_alive:
   Returns the number of processes still "alive"; in other words, those
   whom have not completed and been waited upon. Used in the round_robin
   function to determine whether schedule should continue running. */
int get_num_alive(proc_t *proc_table, int num_programs) {
	int num_alive = 0;

	for ( int i = 0; i < num_programs; i++ ) {
		if ( proc_table[i].alive ) {
			num_alive++;
		}
	}

	return num_alive;
}

/* schedule_programs:
   Essential routine for schedule; adds processes to the proc_table, forks to
   initiate each process, and sets the initial current_process--a pointer used
   throughout round robin scheduling to perform tasks like stopping and starting
   processes. 
 
   Children spawned using fork in schedule_programs() raise a SIGSTOP to themselves
   immediately. When they receive a SIGCONT, they immediately exec(). */
int schedule_programs(proc_t *proc_table, int argc, char **programs, int num_programs) {
	char **start_args_loc = programs;

	for ( int prog = 0; prog < num_programs; prog++ ) {
		if ( strcmp(*start_args_loc, "schedule") == 0 ) {
			error_handler(ERR_NESTED);
			return -1;
		}

		proc_t tmp_process;
		tmp_process.name = *start_args_loc;

		int arg_cnt = 0;
		while ( (start_args_loc[arg_cnt] != NULL) && (strcmp(start_args_loc[arg_cnt], ":")) ) {
			arg_cnt++;
		}
		tmp_process.args = malloc((arg_cnt + 1) * sizeof(char *));
		if ( !tmp_process.args ) {
			error_handler(ERR_MALLOC);
			return -1;
		}
		for ( int i = 0; i < arg_cnt; i++ ) {
			tmp_process.args[i] = start_args_loc[i];
		}
		tmp_process.args[arg_cnt] = NULL;
		tmp_process.alive = 1;
		proc_table[prog] = tmp_process;

		proc_table[prog].pid = fork();
		if ( proc_table[prog].pid < 0 ) {
			/* fork failed */
			perror("schedule: fork");
			error_handler(ERR_FORK);
			return -1;
		} else if ( proc_table[prog].pid == 0 ) {
			/* child */
			if ( raise(SIGSTOP) != 0 ) {
				error_handler(ERR_RAISE);
				perror("schedule");
				return -1;
			}
			/* First, check for program in user's PATH environment variable. If not
			   in PATH, check current directory (or provided path). */
			if ( execvp(proc_table[prog].name, proc_table[prog].args) == -1 ) {
			 	execv(proc_table[prog].name, proc_table[prog].args);
			}
			perror("schedule: exec");
			_exit(157);
		} else if ( proc_table[prog].pid > 0 ) {
			/* parent */
		}

		start_args_loc = find_colon(start_args_loc);
	}

	current_proc = &proc_table[0];
	if ( num_programs != 1 ) {
		next_proc = &proc_table[1];
	} else {
		next_proc = &proc_table[0];
	}

	return 0;
}

/* round_robin:
   Crux of the schedule program (although it doesn't really do too much); periodically
   checks whether there are processes that still need to complete execution. Does NOT
   waste cycles by executing when it has nothing to do; pause() blocks execution until
   it receives a signal (either a SIGCHLD or SIGALRM). */
int round_robin(proc_t *proc_table, int num_programs, int quantum_ms) {
	while ( 1 ) {
		pause();
		if ( get_num_alive(proc_table, num_programs) == 0 ) {
			break;
		}

		/* Check volatile status variables set by signal handlers.
		   Mask the "opposite" signal. */
		if ( received_sigalrm ) {
			sigprocmask(SIG_BLOCK, &sigchld_mask, &sigchld_old_mask);
			context_switch();
			sigprocmask(SIG_SETMASK, &sigchld_old_mask, NULL);
			received_sigalrm = 0;
		} else if ( received_sigchld ) {
			sigprocmask(SIG_BLOCK, &sigalrm_mask, &sigalrm_old_mask);
			while ( 1 ) {	
				int wstatus;
				pid_t pid = waitpid(-1, &wstatus, WNOHANG | WUNTRACED | WCONTINUED);
				if ( pid > 0 ) {
					if ( current_proc->pid == pid && WIFEXITED(wstatus) ) {
						current_proc->alive = 0;
						/* DEBUG_print_dead(); */
						set_timer(0);
						set_timer(quantum_ms);
						context_switch();
					}
				} else if ( pid <= 0 ) {
					break;
				}	
			}
			sigprocmask(SIG_SETMASK, &sigalrm_old_mask, NULL);
			received_sigchld = 0;
		}
	}

	return 0;
}

/* context_switch:
   Handles stopping (SIGSTOP) and resuming (SIGCONT) of processes in the proc_table
   either when SIGALRM goes off or if a process ends. Also moves along current_proc
   and next_proc pointers, contributing to round_robin-style scheduling. */
void context_switch() {
	if ( current_proc == NULL || next_proc == NULL ) {
		perror("schedule: NULL");
		exit(EXIT_FAILURE);
	}

	if ( current_proc->alive ) {
		if ( kill(current_proc->pid, SIGSTOP) == -1 ) {
			current_proc->alive = 0;
			/* DEBUG_print_manual_dead(); */
		}
	}
	current_proc = next_proc;

	int proc_cnt = 0;
	do {
		next_proc++;
		if ( next_proc >= proc_table_start + num_programs ) {
			next_proc = proc_table_start;
		}
		proc_cnt++;
		if ( proc_cnt == num_programs ) {
			break;
		}
	} while ( !next_proc->alive && next_proc != current_proc );

	if ( current_proc->alive ) {
		if ( kill(current_proc->pid, SIGCONT) == -1 ) {
			current_proc->alive = 0;
			/* DEBUG_print_manual_dead(); */
		}
	}

	return;
}

/* main:
   Does some initial setup work and then initiates different parts of scheduler to run. */
int main(int argc, char **argv) {
	if ( argc < 3 ) {
		error_handler(ERR_USAGE);
		exit(EXIT_FAILURE);
	}

	int quantum_ms = atoi(argv[1]);
	if ( quantum_ms <= 0 ) {
		error_handler(ERR_QUANTUM);
		exit(EXIT_FAILURE);
	}

	char **programs = &argv[2];
	if ( (num_programs = get_num_programs(argc, programs)) == -1 ) {
		error_handler(ERR_MAX_PROCS);
		exit(EXIT_FAILURE);
	}

	proc_t *proc_table = malloc(sizeof(proc_t) * num_programs);
	if ( proc_table == NULL ) {
		perror("schedule");
		exit(EXIT_FAILURE);
	}
	proc_table_start = proc_table;

	if ( schedule_programs(proc_table, argc, programs, num_programs) == -1 ) {
		error_handler(ERR_EXEC);
		exit(EXIT_FAILURE);
	}

	/* Set up sigction for SIGCHLD */
	struct sigaction sigchld;
	sigchld.sa_handler = sigchld_handler;
	sigchld.sa_flags = 0;
	sigemptyset(&sigchld.sa_mask);
	sigaction(SIGCHLD, &sigchld, NULL);

	/* Set up sigction for SIGALRM */
	struct sigaction sigalrm;
	sigalrm.sa_handler = alarm_handler;
	sigalrm.sa_flags = 0;
	sigemptyset(&sigalrm.sa_mask);
	sigaction(SIGALRM, &sigalrm, NULL);

	/* Set up signal masks for sigprocmask() */
	sigemptyset(&sigchld_mask);
	sigaddset(&sigchld_mask, SIGCHLD);
	sigemptyset(&sigalrm_mask);
	sigaddset(&sigalrm_mask, SIGALRM);

	if ( set_timer(quantum_ms) == -1 ) {
		error_handler(ERR_TIMER);
		free_resources();
		exit(EXIT_FAILURE);
	}

	/* First (manual) SIGCONT of programs */
	if ( kill(current_proc->pid, SIGCONT) != 0 ) {
		error_handler(ERR_KILL);
		free_resources();
		exit(EXIT_FAILURE);
	}

	round_robin(proc_table, num_programs, quantum_ms);

	free_resources();

	exit(EXIT_SUCCESS);
}

