#define _GNU_SOURCE

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <string.h>
#include <signal.h>

#define MAX_ARGUMENTS 10
#define MAX_PROCESSES 150
#define MAX_STR_LEN 64

#define DEBUG_print_dead() \
	printf("set pid %d to dead\n", current_proc->pid); \

#define DEBUG_print_manual_dead() \
	printf("manually set pid %d to dead\n", current_proc->pid);

#define DEBUG_print_num_alive() \
	printf("num_alive: %d\n", num_alive);

#define DEBUG_print_sigalrm() \
	printf("received a SIGALARM. current proc: %d\n", current_proc->pid);

#define free_resources() \
	for ( int i = 0; i < num_programs; i++ ) { \
		free(proc_table[i].args); \
	} \
	free(proc_table); \

typedef struct {
	char *name;
	char **args;
	pid_t pid;
	int alive;
} proc_t;

enum SCHED_ERR {
	ERR_TIMER,
	ERR_MAX_PROCS,
	ERR_NESTED,
	ERR_MALLOC,
	ERR_FORK,
	ERR_EXEC,
	ERR_USAGE,
	ERR_QUANTUM,
	ERR_MAX_ARGS,
	ERR_RAISE,
	ERR_KILL
};

void alarm_handler(int signal);
void sigchld_handler(int signal);
void error_handler(enum SCHED_ERR error);
int set_timer(int quantum);
char **find_colon(char **argv);
int get_num_programs(int argc, char **argv);
int schedule_programs(proc_t *proc_table, int argc, char **programs, int num_programs);
int round_robin(proc_t *proc_table, int num_programs, int quantum_ms);
void context_switch();
